import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)
print(mydb)

# mydb2 = mysql.connector.connect(
#     host="192.168.0.77",
#     user="root",
#     password=""
# )

mycursor = mydb.cursor()


# sql_query = "CREATE DATABASE python_db"
# mycursor.execute(sql_query)

# sql_query = "SHOW DATABASES"
# mycursor.execute(sql_query)

# for database in mycursor:
#     print(database)

def show_tables(cursor):
    sql_query = "SHOW TABLES"  # SQL
    cursor.execute(sql_query)

    for tables in cursor:
        print(tables)


def create_contact(db_con, cursor, l_name, f_name, m_name=''):
    sql_query = "INSERT INTO contacts (l_name, f_name, m_name) VALUES (%s, %s, %s)"  # SQL
    contact_data = (l_name, f_name, m_name)
    cursor.execute(sql_query, contact_data)
    db_con.commit()


def show_contacts(cursor):
    sql_query = "SELECT * FROM contacts"  # SQL
    cursor.execute(sql_query)

    contacts_all = cursor.fetchall()

    print('Contacts in contacts table:', len(contacts_all))

    for contact in contacts_all:
        print(contact)


while True:
    cmd = input('Введите команду Милорд: ')
    if cmd == 'q':
        break
    elif cmd == 'st':
        show_tables(mycursor)
    elif cmd == 'sc':
        show_contacts(mycursor)
    elif cmd == 'cc':
        udata = input('ФИО:')
        contact_data = udata.split(' ')

        l_name = contact_data[0]
        f_name = contact_data[1]

        m_name = ''
        if len(contact_data) == 3: m_name = contact_data[2]

        create_contact(mydb, mycursor, l_name, f_name, m_name)

mydb.close()