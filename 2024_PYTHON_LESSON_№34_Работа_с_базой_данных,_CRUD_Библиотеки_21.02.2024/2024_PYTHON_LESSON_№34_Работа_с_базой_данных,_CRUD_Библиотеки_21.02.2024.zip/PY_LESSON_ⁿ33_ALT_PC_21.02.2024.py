import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)
print(mydb)

mycursor = mydb.cursor()

# Создаем базу данных, если ее еще нет
sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
mycursor.execute(sql_query)

# Переключаемся на использование базы данных
mycursor.execute("USE python_db")

# Раскомментируйте следующие строки для создания таблицы, если ее нет
sql_query = """
    CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        l_name VARCHAR(255),
        f_name VARCHAR(255),
        m_name VARCHAR(255)
    )
"""
mycursor.execute(sql_query)

def show_tables(cursor):
    sql_query = "SHOW TABLES"
    cursor.execute(sql_query)

    for tables in cursor:
        print(tables)

def delete_contact(db_con, cursor, contact_id):
    sql_query = "DELETE FROM contacts WHERE id = %s"
    contact_data = (contact_id,)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def create_contact(db_con, cursor, l_name, f_name, m_name=''):
    sql_query = "INSERT INTO contacts (l_name, f_name, m_name) VALUES (%s, %s, %s)"
    contact_data = (l_name, f_name, m_name)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def update_contact(db_con, cursor, contact_id, l_name, f_name, m_name=''):
    sql_query = "UPDATE contacts SET l_name = %s, f_name = %s, m_name = %s WHERE id = %s"
    contact_data = (l_name, f_name, m_name, contact_id)
    cursor.execute(sql_query, contact_data)
    db_con.commit()


def show_contacts(cursor):
    sql_query = "SELECT * FROM contacts"
    cursor.execute(sql_query)

    contacts_all = cursor.fetchall()

    print('Contacts in contacts table:', len(contacts_all))

    for contact in contacts_all:
        print(contact)

while True:
    cmd = input('Введите команду Милорд: ')
    if cmd == 'q':
        break
    elif cmd == 'st':
        show_tables(mycursor)
    elif cmd == 'sc':
        show_contacts(mycursor)
    elif cmd == 'cc':
        udata = input('ФИО:')
        contact_data = udata.split(' ')

        l_name = contact_data[0]
        f_name = contact_data[1]

        m_name = ''
        if len(contact_data) == 3: m_name = contact_data[2]

        create_contact(mydb, mycursor, l_name, f_name, m_name)
    elif cmd == 'uc':
        show_contacts(mycursor)

        contact_id = int(input("Введите ID контакта:"))

        udata = input('ФИО:')
        contact_data = udata.split(' ')

        l_name = contact_data[0]
        f_name = contact_data[1]

        m_name = ''
        if len(contact_data) == 3: m_name = contact_data[2]
        update_contact(mydb, mycursor, contact_id, l_name, f_name, m_name)
    elif cmd == 'dc':
        show_contacts(mycursor)

        contact_id = int(input("Введите ID контакта, который нужно удалить:"))
        delete_contact(mydb, mycursor, contact_id)




mydb.close()