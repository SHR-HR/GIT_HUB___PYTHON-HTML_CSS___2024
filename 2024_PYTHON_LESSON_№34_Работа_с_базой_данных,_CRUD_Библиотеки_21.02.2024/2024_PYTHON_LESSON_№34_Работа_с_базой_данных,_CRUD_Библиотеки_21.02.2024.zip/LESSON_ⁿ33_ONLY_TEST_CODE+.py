import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)
print(mydb)

mycursor = mydb.cursor()

# sql_query = "CREATE DATABASE python_db"
# mycursor.execute(sql_query)

# sql_query = "SHOW DATABASES"
# mycursor.execute(sql_query)
#
# for database in mycursor:
#     print(database)

sql_query = "SHOW TABLES"
mycursor.execute(sql_query)

for tables in mycursor:
    print(tables)