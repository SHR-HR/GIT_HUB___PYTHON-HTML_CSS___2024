'''
Дата выполнения Домашней-Работы: 21 - ФЕВРАЛЯ - 22 ФЕВРАЛЯ 2024 года.
'''
'''
Домашняя работа

Курс: Разработка Web-приложений на Python, с применением Фреймворка Django
Дисциплина: Основы программирования на Python

Домашнее задание №33 : Работа с базой данных, CRUD. Библиотеки psycopg2 (postgresql) и pyodbc (mysql)

Выполните следующие задания:

Задание №1
Доработайте обновление контакта и удаление контакта в ткинтер.
'''
'''
Урок от 21.02.2024
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ #
'''
Выполнение задания:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
ВАРИАНТ №1.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
КОД:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)

mycursor = mydb.cursor()

# Создаем базу данных, если ее еще нет
sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
mycursor.execute(sql_query)

# Переключаемся на использование базы данных
mycursor.execute("USE python_db")

# Раскомментируйте следующие строки для создания таблицы, если ее нет
sql_query = """
    CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        l_name VARCHAR(255),
        f_name VARCHAR(255),
        m_name VARCHAR(255),
        phone_number VARCHAR(20),
        email VARCHAR(255)
    )
"""
mycursor.execute(sql_query)

def show_tables(cursor):
    sql_query = "SHOW TABLES"
    cursor.execute(sql_query)

    for tables in cursor:
        print(tables)

def delete_contact(db_con, cursor, contact_id):
    sql_query = "DELETE FROM contacts WHERE id = %s"
    contact_data = (contact_id,)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def create_contact(db_con, cursor, l_name, f_name, m_name='', phone_number='', email=''):
    sql_query = "INSERT INTO contacts (l_name, f_name, m_name, phone_number, email) VALUES (%s, %s, %s, %s, %s)"
    contact_data = (l_name, f_name, m_name, phone_number, email)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def update_contact(db_con, cursor, contact_id, l_name, f_name, m_name='', phone_number='', email=''):
    sql_query = "UPDATE contacts SET l_name = %s, f_name = %s, m_name = %s, phone_number = %s, email = %s WHERE id = %s"
    contact_data = (l_name, f_name, m_name, phone_number, email, contact_id)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def show_contacts(cursor):
    sql_query = "SELECT * FROM contacts"
    cursor.execute(sql_query)

    contacts_all = cursor.fetchall()

    print('Contacts in contacts table:', len(contacts_all))

    for contact in contacts_all:
        print(contact)

def create_tables():
    # Раскомментируйте следующие строки для создания таблицы, если ее нет
    sql_query = """
        CREATE TABLE IF NOT EXISTS another_table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            field1 VARCHAR(255),
            field2 VARCHAR(255)
        )
    """
    mycursor.execute(sql_query)

# Создаем GUI с использованием tkinter
class ContactManagerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Менеджер КОНТАКТОВ")

        self.create_contact_button = tk.Button(master, text="Создать контакт", command=self.create_contact)
        self.create_contact_button.pack()

        self.update_contact_button = tk.Button(master, text="Обновить контакт", command=self.update_contact)
        self.update_contact_button.pack()

        self.delete_contact_button = tk.Button(master, text="Удалить контакт", command=self.delete_contact)
        self.delete_contact_button.pack()

        self.create_tables_button = tk.Button(master, text="Создать таблицу", command=create_tables)
        self.create_tables_button.pack()

        self.show_tables_button = tk.Button(master, text="Показывать таблицы", command=lambda: show_tables(mycursor))
        self.show_tables_button.pack()

        self.show_contacts_button = tk.Button(master, text="Показать контакты", command=lambda: show_contacts(mycursor))
        self.show_contacts_button.pack()

        self.exit_button = tk.Button(master, text="Выход", command=master.quit)
        self.exit_button.pack()

    def create_contact(self):
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        create_contact(mydb, mycursor, l_name, f_name, m_name, phone_number, email)
        print("Контакт создан успешно!")

    def update_contact(self):
        contact_id = simpledialog.askinteger("Update Contact", "Введите идентификатор контакта:")
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        update_contact(mydb, mycursor, contact_id, l_name, f_name, m_name, phone_number, email)
        print("Контакт успешно обновлен! Поздравляю!!!")

    def delete_contact(self):
        contact_id = simpledialog.askinteger("Удалить контакт", "Введите идентификатор контакта:")
        delete_contact(mydb, mycursor, contact_id)
        print("Контакт успешно удален! К чертовой бабушке!")

    def validate_input(self, message):
        while True:
            user_input = simpledialog.askstring("Input", message)
            if user_input.isalpha():
                return user_input
            else:
                messagebox.showerror("Ошибка", "Введите только буквы")

    def validate_phone_number(self, message):
        while True:
            phone_number = simpledialog.askstring("Phone Number", message)
            if phone_number.replace('+', '').isdigit():
                return phone_number
            else:
                messagebox.showerror("Ошибка", "Введите корректный номер телефона")

    def validate_email(self, message):
        while True:
            email = simpledialog.askstring("Email", message)
            if '@' in email and '.' in email:
                return email
            else:
                messagebox.showerror("Ошибка", "Введите корректный адрес электронной почты")

def main():
    root = tk.Tk()
    app = ContactManagerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

mydb.close()
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг №1: Импорт библиотек
'''
import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox
'''
Импорт библиотеки для работы с MySQL (mysql.connector).
Импорт библиотеки для создания графического интерфейса (tkinter).
Импорт функций simpledialog и messagebox из tkinter для создания диалоговых окон.
'''
'''
Шаг №2: Подключение к базе данных MySQL
'''
mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)
'''
Создание подключения к базе данных MySQL с указанием хоста, пользователя, пароля и названия базы данных.
'''
'''
Шаг №3: Создание курсора для выполнения SQL-запросов
'''
mycursor = mydb.cursor()
'''
Создание курсора для выполнения операций с базой данных.
'''
'''
Шаг №4: Создание базы данных (если ее нет)
'''
sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
mycursor.execute(sql_query)
'''
Выполнение SQL-запроса для создания базы данных python_db, если ее еще нет.
'''
'''
Шаг №5: Переключение на использование базы данных
'''
mycursor.execute("USE python_db")
'''
Указание текущей базы данных.
'''
'''
Шаг №6: Создание таблицы контактов (если ее нет)
'''
sql_query = """
    CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        l_name VARCHAR(255),
        f_name VARCHAR(255),
        m_name VARCHAR(255),
        phone_number VARCHAR(20),
        email VARCHAR(255)
    )
"""
mycursor.execute(sql_query)
'''
Выполнение SQL-запроса для создания таблицы contacts, если она еще не существует.
'''
'''
Шаг №7: Определение функций для работы с базой данных
'''
'''
show_tables(cursor): Выводит список таблиц в базе данных.
delete_contact(db_con, cursor, contact_id): Удаляет контакт по заданному идентификатору.
create_contact(db_con, cursor, l_name, f_name, m_name='', phone_number='', email=''): Создает новый контакт.
update_contact(db_con, cursor, contact_id, l_name, f_name, m_name='', phone_number='', email=''): Обновляет контакт.
'''
'''
Шаг №8: Вывод информации о контактах и таблицах
'''
def show_contacts(cursor):
    sql_query = "SELECT * FROM contacts"
    cursor.execute(sql_query)

    contacts_all = cursor.fetchall()

    print('Contacts in contacts table:', len(contacts_all))

    for contact in contacts_all:
        print(contact)

def show_tables(cursor):
    sql_query = "SHOW TABLES"
    cursor.execute(sql_query)

    for tables in cursor:
        print(tables)
'''
Шаг №9: Создание дополнительной таблицы (если ее нет)
'''
def create_tables():
    sql_query = """
        CREATE TABLE IF NOT EXISTS another_table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            field1 VARCHAR(255),
            field2 VARCHAR(255)
        )
    """
    mycursor.execute(sql_query)
'''
Шаг №10: Создание GUI с использованием Tkinter
'''
class ContactManagerApp:
    # ... (инициализация и методы для работы с интерфейсом)
''''
Создается класс ContactManagerApp, представляющий графическое приложение для управления контактами.
В конструкторе класса создаются кнопки для создания, обновления и удаления контактов,
 а также для создания таблиц и просмотра таблиц и контактов.
''''
'''
Шаг №11: Валидация ввода данных через диалоговые окна
'''


def validate_input(self, message):


# ... (валидация для фамилии, имени, отчества)

def validate_phone_number(self, message):


# ... (валидация для номера телефона)

def validate_email(self, message):
# ... (валидация для адреса электронной почты)
''''
Реализация методов для валидации ввода данных пользователем через диалоговые окна Tkinter.
''''
'''
Шаг №12: Запуск приложения
'''
def main():
    root = tk.Tk()
    app = ContactManagerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

mydb.close()
'''
Запуск основного цикла приложения при выполнении скрипта.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
ВАРИАНТ №2.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
КОД:
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox

class DatabaseManager:
    def __init__(self, host, user, password, database):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.db.cursor()
        self.create_database()
        self.use_database()
        self.create_contacts_table()

    def create_database(self):
        sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
        self.cursor.execute(sql_query)

    def use_database(self):
        self.cursor.execute("USE python_db")

    def create_contacts_table(self):
        sql_query = """
            CREATE TABLE IF NOT EXISTS contacts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                l_name VARCHAR(255),
                f_name VARCHAR(255),
                m_name VARCHAR(255),
                phone_number VARCHAR(20),
                email VARCHAR(255)
            )
        """
        self.cursor.execute(sql_query)

    def execute_query(self, query, data=None):
        self.cursor.execute(query, data)
        self.db.commit()

    def fetch_all(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()

class ContactManagerApp:
    def __init__(self, master, database_manager):
        self.master = master
        self.master.title("Менеджер КОНТАКТОВ")
        self.db_manager = database_manager

        self.create_contact_button = tk.Button(master, text="Создать контакт", command=self.create_contact)
        self.create_contact_button.pack()

        self.update_contact_button = tk.Button(master, text="Обновить контакт", command=self.update_contact)
        self.update_contact_button.pack()

        self.delete_contact_button = tk.Button(master, text="Удалить контакт", command=self.delete_contact)
        self.delete_contact_button.pack()

        self.create_tables_button = tk.Button(master, text="Создать таблицу", command=self.create_tables)
        self.create_tables_button.pack()

        self.show_tables_button = tk.Button(master, text="Показывать таблицы", command=self.show_tables)
        self.show_tables_button.pack()

        self.show_contacts_button = tk.Button(master, text="Показать контакты", command=self.show_contacts)
        self.show_contacts_button.pack()

        self.exit_button = tk.Button(master, text="Выход", command=master.quit)
        self.exit_button.pack()

    def create_contact(self):
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        self.db_manager.execute_query("INSERT INTO contacts (l_name, f_name, m_name, phone_number, email) VALUES (%s, %s, %s, %s, %s)", (l_name, f_name, m_name, phone_number, email))
        print("Контакт создан успешно!")

    def update_contact(self):
        contact_id = simpledialog.askinteger("Update Contact", "Введите идентификатор контакта:")
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        self.db_manager.execute_query("UPDATE contacts SET l_name = %s, f_name = %s, m_name = %s, phone_number = %s, email = %s WHERE id = %s", (l_name, f_name, m_name, phone_number, email, contact_id))
        print("Контакт успешно обновлен! Поздравляю!!!")

    def delete_contact(self):
        contact_id = simpledialog.askinteger("Удалить контакт", "Введите идентификатор контакта:")
        self.db_manager.execute_query("DELETE FROM contacts WHERE id = %s", (contact_id,))
        print("Контакт успешно удален! К чертовой бабушке!")

    def create_tables(self):
        self.db_manager.execute_query("""
            CREATE TABLE IF NOT EXISTS another_table (
                id INT AUTO_INCREMENT PRIMARY KEY,
                field1 VARCHAR(255),
                field2 VARCHAR(255)
            )
        """)

    def show_tables(self):
        tables = self.db_manager.fetch_all("SHOW TABLES")
        for table in tables:
            print(table)

    def show_contacts(self):
        contacts = self.db_manager.fetch_all("SELECT * FROM contacts")
        print('Contacts in contacts table:', len(contacts))
        for contact in contacts:
            print(contact)

    def validate_input(self, message):
        while True:
            user_input = simpledialog.askstring("Input", message)
            if user_input.isalpha():
                return user_input
            else:
                messagebox.showerror("Ошибка", "Введите только буквы")

    def validate_phone_number(self, message):
        while True:
            phone_number = simpledialog.askstring("Phone Number", message)
            if phone_number.replace('+', '').isdigit():
                return phone_number
            else:
                messagebox.showerror("Ошибка", "Введите корректный номер телефона")

    def validate_email(self, message):
        while True:
            email = simpledialog.askstring("Email", message)
            if '@' in email and '.' in email:
                return email
            else:
                messagebox.showerror("Ошибка", "Введите корректный адрес электронной почты")

def main():
    db_manager = DatabaseManager(host="localhost", user="root", password="", database="python_db")
    root = tk.Tk()
    app = ContactManagerApp(root, db_manager)
    root.mainloop()

if __name__ == "__main__":
    main()
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
'''
Шаг 1:
'''
import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox
'''
Этот шаг включает импорт необходимых библиотек для работы с базой 
данных MySQL (mysql.connector) и для создания графического интерфейса (tkinter).
'''
'''
Шаг 2: Создание класса DatabaseManager
'''
class DatabaseManager:
    def __init__(self, host, user, password, database):
        # Конструктор класса DatabaseManager
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.db.cursor()
        self.create_database()
        self.use_database()
        self.create_contacts_table()
'''
Создается класс DatabaseManager, который управляет базой данных.
В конструкторе устанавливается соединение с базой данных, создается курсор для выполнения SQL-запросов,
 и вызываются методы для инициализации базы данных и таблицы контактов.
'''
'''
Шаг 3: Инициализация базы данных
'''
def create_database(self):
    sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
    self.cursor.execute(sql_query)
def use_database(self):
    self.cursor.execute("USE python_db")
'''
create_database: Проверяет существование базы данных "python_db" и создает ее, если она не существует.
use_database: Устанавливает текущую базу данных в "python_db".
'''
'''
Шаг 4: Создание таблицы контактов
'''
def create_contacts_table(self):
    sql_query = """
        CREATE TABLE IF NOT EXISTS contacts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            l_name VARCHAR(255),
            f_name VARCHAR(255),
            m_name VARCHAR(255),
            phone_number VARCHAR(20),
            email VARCHAR(255)
        )
    """
    self.cursor.execute(sql_query)
'''
Создается таблица "contacts" с полями id, l_name, f_name, m_name, phone_number, и email.
Поле id - автоинкрементируемый первичный ключ.
'''
'''
Шаг 5: Методы для выполнения SQL-запросов
'''
def execute_query(self, query, data=None):
    self.cursor.execute(query, data)
    self.db.commit()
def fetch_all(self, query):
    self.cursor.execute(query)
    return self.cursor.fetchall()
'''
execute_query: Принимает SQL-запрос и данные, выполняет запрос и коммитит изменения.
fetch_all: Принимает SQL-запрос, выполняет его и возвращает все строки результата.
'''
'''
Шаг 6: Создание класса ContactManagerApp
'''
class ContactManagerApp:
    def __init__(self, master, database_manager):
        # Конструктор класса ContactManagerApp
        self.master = master
        self.master.title("Менеджер КОНТАКТОВ")
        self.db_manager = database_manager
        # ... остальные элементы GUI ...
'''
Создается класс ContactManagerApp, представляющий графический интерфейс пользователя.
В конструкторе создается окно с заголовком "Менеджер КОНТАКТОВ", и передается объект DatabaseManager.
'''
'''
Шаг 7: Элементы GUI и их связанные методы
'''
self.create_contact_button = tk.Button(master, text="Создать контакт", command=self.create_contact)
self.create_contact_button.pack()
# ... другие кнопки и их методы ...
'''
Создаются кнопки для различных операций (создание, обновление, удаление контакта, создание таблицы,
 показывание таблиц и контактов).
Каждая кнопка связана с соответствующим методом.
'''
'''
Шаг 8: Методы для операций с базой данных
'''
def create_contact(self):
# ... код для создания контакта ...

def update_contact(self):
# ... код для обновления контакта ...

def delete_contact(self):
# ... код для удаления контакта ...

def create_tables(self):
# ... код для создания таблицы ...

def show_tables(self):
# ... код для показа таблиц ...

def show_contacts(self):
# ... код для показа контактов ...
''''
Методы для выполнения операций CRUD с использованием методов execute_query и fetch_all объекта DatabaseManager.
''''
'''
Шаг 9: Валидация ввода
'''
def validate_input(self, message):
# ... код для валидации ввода ...

def validate_phone_number(self, message):
# ... код для валидации номера телефона ...

def validate_email(self, message):
# ... код для валидации адреса электронной почты ...

''''
Методы для валидации ввода пользователя с использованием simpledialog и messagebox из tkinter.
''''
'''
Шаг 10: Главная функция и запуск приложения
'''
def main():
    # ... код для инициализации DatabaseManager и Tk ...

if __name__ == "__main__":
    main()
'''
Функция main создает объект DatabaseManager и окно Tk, и запускает главный цикл приложения.
'''
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~
# ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~