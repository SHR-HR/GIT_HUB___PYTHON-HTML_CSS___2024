from tkinter import *
from db_con import *


window = Tk()
window.title("Контакты")
window.geometry("720x480")
# window.iconbitmap(r'./assets/icon.ico')
window.resizable(False, False)






window.mainloop()








