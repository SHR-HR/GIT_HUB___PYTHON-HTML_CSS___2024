import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox

class DatabaseManager:
    def __init__(self, host, user, password, database):
        self.db = mysql.connector.connect(
            host=host,
            user=user,
            password=password,
            database=database
        )
        self.cursor = self.db.cursor()
        self.create_database()
        self.use_database()
        self.create_contacts_table()

    def create_database(self):
        sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
        self.cursor.execute(sql_query)

    def use_database(self):
        self.cursor.execute("USE python_db")

    def create_contacts_table(self):
        sql_query = """
            CREATE TABLE IF NOT EXISTS contacts (
                id INT AUTO_INCREMENT PRIMARY KEY,
                l_name VARCHAR(255),
                f_name VARCHAR(255),
                m_name VARCHAR(255),
                phone_number VARCHAR(20),
                email VARCHAR(255)
            )
        """
        self.cursor.execute(sql_query)

    def execute_query(self, query, data=None):
        self.cursor.execute(query, data)
        self.db.commit()

    def fetch_all(self, query):
        self.cursor.execute(query)
        return self.cursor.fetchall()

class ContactManagerApp:
    def __init__(self, master, database_manager):
        self.master = master
        self.master.title("Менеджер КОНТАКТОВ")
        self.db_manager = database_manager

        self.create_contact_button = tk.Button(master, text="Создать контакт", command=self.create_contact)
        self.create_contact_button.pack()

        self.update_contact_button = tk.Button(master, text="Обновить контакт", command=self.update_contact)
        self.update_contact_button.pack()

        self.delete_contact_button = tk.Button(master, text="Удалить контакт", command=self.delete_contact)
        self.delete_contact_button.pack()

        self.create_tables_button = tk.Button(master, text="Создать таблицу", command=self.create_tables)
        self.create_tables_button.pack()

        self.show_tables_button = tk.Button(master, text="Показывать таблицы", command=self.show_tables)
        self.show_tables_button.pack()

        self.show_contacts_button = tk.Button(master, text="Показать контакты", command=self.show_contacts)
        self.show_contacts_button.pack()

        self.exit_button = tk.Button(master, text="Выход", command=master.quit)
        self.exit_button.pack()

    def create_contact(self):
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        self.db_manager.execute_query("INSERT INTO contacts (l_name, f_name, m_name, phone_number, email) VALUES (%s, %s, %s, %s, %s)", (l_name, f_name, m_name, phone_number, email))
        print("Контакт создан успешно!")

    def update_contact(self):
        contact_id = simpledialog.askinteger("Update Contact", "Введите идентификатор контакта:")
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        self.db_manager.execute_query("UPDATE contacts SET l_name = %s, f_name = %s, m_name = %s, phone_number = %s, email = %s WHERE id = %s", (l_name, f_name, m_name, phone_number, email, contact_id))
        print("Контакт успешно обновлен! Поздравляю!!!")

    def delete_contact(self):
        contact_id = simpledialog.askinteger("Удалить контакт", "Введите идентификатор контакта:")
        self.db_manager.execute_query("DELETE FROM contacts WHERE id = %s", (contact_id,))
        print("Контакт успешно удален! К чертовой бабушке!")

    def create_tables(self):
        self.db_manager.execute_query("""
            CREATE TABLE IF NOT EXISTS another_table (
                id INT AUTO_INCREMENT PRIMARY KEY,
                field1 VARCHAR(255),
                field2 VARCHAR(255)
            )
        """)

    def show_tables(self):
        tables = self.db_manager.fetch_all("SHOW TABLES")
        for table in tables:
            print(table)

    def show_contacts(self):
        contacts = self.db_manager.fetch_all("SELECT * FROM contacts")
        print('Contacts in contacts table:', len(contacts))
        for contact in contacts:
            print(contact)

    def validate_input(self, message):
        while True:
            user_input = simpledialog.askstring("Input", message)
            if user_input.isalpha():
                return user_input
            else:
                messagebox.showerror("Ошибка", "Введите только буквы")

    def validate_phone_number(self, message):
        while True:
            phone_number = simpledialog.askstring("Phone Number", message)
            if phone_number.replace('+', '').isdigit():
                return phone_number
            else:
                messagebox.showerror("Ошибка", "Введите корректный номер телефона")

    def validate_email(self, message):
        while True:
            email = simpledialog.askstring("Email", message)
            if '@' in email and '.' in email:
                return email
            else:
                messagebox.showerror("Ошибка", "Введите корректный адрес электронной почты")

def main():
    db_manager = DatabaseManager(host="localhost", user="root", password="", database="python_db")
    root = tk.Tk()
    app = ContactManagerApp(root, db_manager)
    root.mainloop()

if __name__ == "__main__":
    main()
