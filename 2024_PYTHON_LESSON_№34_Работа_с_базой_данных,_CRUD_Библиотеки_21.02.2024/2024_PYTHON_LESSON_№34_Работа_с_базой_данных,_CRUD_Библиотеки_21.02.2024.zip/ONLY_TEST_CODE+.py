import mysql.connector
import tkinter as tk
from tkinter import simpledialog, messagebox

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="python_db"
)

mycursor = mydb.cursor()

# Создаем базу данных, если ее еще нет
sql_query = "CREATE DATABASE IF NOT EXISTS python_db"
mycursor.execute(sql_query)

# Переключаемся на использование базы данных
mycursor.execute("USE python_db")

# Раскомментируйте следующие строки для создания таблицы, если ее нет
sql_query = """
    CREATE TABLE IF NOT EXISTS contacts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        l_name VARCHAR(255),
        f_name VARCHAR(255),
        m_name VARCHAR(255),
        phone_number VARCHAR(20),
        email VARCHAR(255)
    )
"""
mycursor.execute(sql_query)

def show_tables(cursor):
    sql_query = "SHOW TABLES"
    cursor.execute(sql_query)

    for tables in cursor:
        print(tables)

def delete_contact(db_con, cursor, contact_id):
    sql_query = "DELETE FROM contacts WHERE id = %s"
    contact_data = (contact_id,)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def create_contact(db_con, cursor, l_name, f_name, m_name='', phone_number='', email=''):
    sql_query = "INSERT INTO contacts (l_name, f_name, m_name, phone_number, email) VALUES (%s, %s, %s, %s, %s)"
    contact_data = (l_name, f_name, m_name, phone_number, email)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def update_contact(db_con, cursor, contact_id, l_name, f_name, m_name='', phone_number='', email=''):
    sql_query = "UPDATE contacts SET l_name = %s, f_name = %s, m_name = %s, phone_number = %s, email = %s WHERE id = %s"
    contact_data = (l_name, f_name, m_name, phone_number, email, contact_id)
    cursor.execute(sql_query, contact_data)
    db_con.commit()

def show_contacts(cursor):
    sql_query = "SELECT * FROM contacts"
    cursor.execute(sql_query)

    contacts_all = cursor.fetchall()

    print('Contacts in contacts table:', len(contacts_all))

    for contact in contacts_all:
        print(contact)

def create_tables():
    # Раскомментируйте следующие строки для создания таблицы, если ее нет
    sql_query = """
        CREATE TABLE IF NOT EXISTS another_table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            field1 VARCHAR(255),
            field2 VARCHAR(255)
        )
    """
    mycursor.execute(sql_query)

# Создаем GUI с использованием tkinter
class ContactManagerApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Менеджер КОНТАКТОВ")

        self.create_contact_button = tk.Button(master, text="Создать контакт", command=self.create_contact)
        self.create_contact_button.pack()

        self.update_contact_button = tk.Button(master, text="Обновить контакт", command=self.update_contact)
        self.update_contact_button.pack()

        self.delete_contact_button = tk.Button(master, text="Удалить контакт", command=self.delete_contact)
        self.delete_contact_button.pack()

        self.create_tables_button = tk.Button(master, text="Создать таблицу", command=create_tables)
        self.create_tables_button.pack()

        self.show_tables_button = tk.Button(master, text="Показывать таблицы", command=lambda: show_tables(mycursor))
        self.show_tables_button.pack()

        self.show_contacts_button = tk.Button(master, text="Показать контакты", command=lambda: show_contacts(mycursor))
        self.show_contacts_button.pack()

        self.exit_button = tk.Button(master, text="Выход", command=master.quit)
        self.exit_button.pack()

    def create_contact(self):
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        create_contact(mydb, mycursor, l_name, f_name, m_name, phone_number, email)
        print("Контакт создан успешно!")

    def update_contact(self):
        contact_id = simpledialog.askinteger("Update Contact", "Введите идентификатор контакта:")
        l_name = self.validate_input("Введите фамилию:")
        f_name = self.validate_input("Введите имя:")
        m_name = self.validate_input("Введите отчество:")
        phone_number = self.validate_phone_number("Введите номер телефона:")
        email = self.validate_email("Введите адрес электронной почты:")
        update_contact(mydb, mycursor, contact_id, l_name, f_name, m_name, phone_number, email)
        print("Контакт успешно обновлен! Поздравляю!!!")

    def delete_contact(self):
        contact_id = simpledialog.askinteger("Удалить контакт", "Введите идентификатор контакта:")
        delete_contact(mydb, mycursor, contact_id)
        print("Контакт успешно удален! К чертовой бабушке!")

    def validate_input(self, message):
        while True:
            user_input = simpledialog.askstring("Input", message)
            if user_input.isalpha():
                return user_input
            else:
                messagebox.showerror("Ошибка", "Введите только буквы")

    def validate_phone_number(self, message):
        while True:
            phone_number = simpledialog.askstring("Phone Number", message)
            if phone_number.replace('+', '').isdigit():
                return phone_number
            else:
                messagebox.showerror("Ошибка", "Введите корректный номер телефона")

    def validate_email(self, message):
        while True:
            email = simpledialog.askstring("Email", message)
            if '@' in email and '.' in email:
                return email
            else:
                messagebox.showerror("Ошибка", "Введите корректный адрес электронной почты")

def main():
    root = tk.Tk()
    app = ContactManagerApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()

mydb.close()
